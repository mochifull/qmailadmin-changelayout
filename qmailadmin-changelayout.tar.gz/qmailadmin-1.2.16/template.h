/* 
 * $Id: template.h,v 1.1.2.1 2004-11-20 01:10:41 tomcollins Exp $
 */

int send_template(char *actualfile);
int send_template_now(char *filename);
