/* 
 * $Id: cgi.h,v 1.1.2.1 2004-11-20 01:10:41 tomcollins Exp $
 */

void get_cgi();
int GetValue (char *, char *, char *, int);
