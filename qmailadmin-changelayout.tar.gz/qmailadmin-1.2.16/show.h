/* 
 * $Id: show.h,v 1.1.2.1 2004-11-20 01:10:41 tomcollins Exp $
 */

#include <time.h>

void show_menu(char *, char *, time_t);
void show_login();
